# Three-Reaction Animated Frontend

This is the frontend-only version of the companion chatbot.

It includes:

- media-based character animation
- three reaction buttons
- private local backend for model calls
- mood changes while chatting
- Hugging Face model connection
- mobile-friendly chat layout
- packages ready for Rive, Lottie, and Motion upgrades

## Run In Windows VM

Open this folder in VS Code, then create your local `.env`:

```powershell
copy .env.example .env
```

Open `.env` and put your Hugging Face token here:

```text
HF_TOKEN=hf_your_real_token_here
```

Keep the model as:

```text
HF_MODEL=Qwen/Qwen-AgentWorld-35B-A3B
```

Then run:

```powershell
npm install
npm run dev
```

Open the local link shown by Vite, usually:

```text
http://localhost:5173
```

## What To Build Next

1. Add your three character animation files.
2. Test the model reply from the local backend.
3. Deploy the frontend and backend.

## Asset Folders

```text
public/animations
public/reactions
public/audio
public/videos
```

## Character Animations

Place your three animation files here:

```text
public/animations/happy.mp4
public/animations/blush.mp4
public/animations/calm.mp4
```

The app will switch between only these three modes:

```text
Happy
Blush
Calm
```

You can also use `.webm`, `.gif`, `.png`, `.jpg`, or `.webp`. If you use a different filename or extension, update `.env`:

```text
VITE_HAPPY_ANIMATION_SRC=/animations/happy.gif
VITE_BLUSH_ANIMATION_SRC=/animations/blush.gif
VITE_CALM_ANIMATION_SRC=/animations/calm.gif
```

## Background Video

Place your 10-second MP4 here:

```text
public/videos/chat-background.mp4
```

The app will automatically play it as a muted looping background.

## Token Placement

Put your Hugging Face token only in:

```text
.env
```

Use:

```text
HF_TOKEN=hf_your_real_token_here
```

Do not put the token in:

```text
src
public
VITE_HF_TOKEN
```

Anything with `VITE_` can be exposed to the browser.

## Model Note

This project calls:

```text
Qwen/Qwen-AgentWorld-35B-A3B
```

through:

```text
HF_API_BASE=https://router.huggingface.co/v1
```

If Hugging Face router does not serve this exact large model for your account, run it through your own vLLM/SGLang server and set:

```text
HF_API_BASE=http://localhost:8000/v1
HF_TOKEN=EMPTY
```

## Deployment Note

Firebase Hosting can host the React frontend, but it cannot safely store `HF_TOKEN` by itself. For production, deploy `server/index.js` to a backend host such as Render, Railway, Cloud Run, Cloudflare Workers, or Firebase Functions, then keep `HF_TOKEN` in that backend host's secret/environment settings.

## Files To Edit Most

```text
src/App.jsx
src/components/CharacterAnimation.jsx
server/index.js
src/styles.css
```
