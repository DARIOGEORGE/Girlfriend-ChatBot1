# Mira Animated Frontend

This is the frontend-only version of the companion chatbot.

It includes:

- animated character built with layered CSS
- reaction buttons
- mood changes while chatting
- local demo replies
- mobile-friendly chat layout
- packages ready for Rive, Lottie, and Motion upgrades

## Run In Windows VM

Open this folder in VS Code, then run:

```powershell
npm install
npm run dev
```

Open the local link shown by Vite, usually:

```text
http://localhost:5173
```

## What To Build Next

1. Replace the CSS avatar with a Rive character file.
2. Add Lottie effects for hearts and sparkles.
3. Connect the chat box to your model through a backend.
4. Deploy the built frontend to Firebase Hosting.

## Asset Folders

```text
public/animations
public/reactions
public/audio
public/videos
```

## Background Video

Place your 10-second MP4 here:

```text
public/videos/chat-background.mp4
```

The app will automatically play it as a muted looping background.

## Files To Edit Most

```text
src/App.jsx
src/components/CompanionAvatar.jsx
src/styles.css
```
