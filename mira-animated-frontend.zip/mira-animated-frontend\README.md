# Three-Reaction Animated Frontend

This is the frontend-only version of the companion chatbot.

It includes:

- media-based character animation
- three reaction buttons
- mood changes while chatting
- local demo replies
- mobile-friendly chat layout
- packages ready for Rive, Lottie, and Motion upgrades

## Run In Windows VM

Open this folder in VS Code, then run:

```powershell
npm install
npm run dev
```

Open the local link shown by Vite, usually:

```text
http://localhost:5173
```

## What To Build Next

1. Add your three character animation files.
2. Connect the chat box to your model through a backend.
3. Deploy the built frontend to Firebase Hosting.

## Asset Folders

```text
public/animations
public/reactions
public/audio
public/videos
```

## Character Animations

Place your three animation files here:

```text
public/animations/happy.mp4
public/animations/blush.mp4
public/animations/calm.mp4
```

The app will switch between only these three modes:

```text
Happy
Blush
Calm
```

You can also use `.webm`, `.gif`, `.png`, `.jpg`, or `.webp`. If you use a different filename or extension, update `.env`:

```text
VITE_HAPPY_ANIMATION_SRC=/animations/happy.gif
VITE_BLUSH_ANIMATION_SRC=/animations/blush.gif
VITE_CALM_ANIMATION_SRC=/animations/calm.gif
```

## Background Video

Place your 10-second MP4 here:

```text
public/videos/chat-background.mp4
```

The app will automatically play it as a muted looping background.

## Files To Edit Most

```text
src/App.jsx
src/components/CharacterAnimation.jsx
src/styles.css
```
