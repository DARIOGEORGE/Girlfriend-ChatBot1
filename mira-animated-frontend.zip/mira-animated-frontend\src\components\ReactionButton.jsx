export function ReactionButton({ label, Icon, isActive, onClick }) {
  return (
    <button
      className={`reactionButton ${isActive ? "active" : ""}`}
      type="button"
      onClick={onClick}
      aria-pressed={isActive}
      title={label}
    >
      <Icon size={18} />
      <span>{label}</span>
    </button>
  );
}
