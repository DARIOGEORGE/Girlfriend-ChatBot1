import "dotenv/config";
import cors from "cors";
import express from "express";

const app = express();
const port = Number(process.env.PORT || 8787);
const hfApiBase = process.env.HF_API_BASE || "https://router.huggingface.co/v1";
const hfModel = process.env.HF_MODEL || "Qwen/Qwen-AgentWorld-35B-A3B";
const hfToken = process.env.HF_TOKEN;

const systemPrompt =
  process.env.SYSTEM_PROMPT ||
  [
    "You are a warm, playful AI companion inside an animated chat app.",
    "Reply naturally in 1 to 4 short sentences.",
    "Be supportive and charming, but be honest that you are AI if asked.",
    "Do not encourage unhealthy dependency, isolation, self-harm, or unsafe behavior."
  ].join(" ");

app.use(cors());
app.use(express.json({ limit: "1mb" }));

function cleanReply(text) {
  return String(text || "")
    .replace(/<think>[\s\S]*?<\/think>/gi, "")
    .trim();
}

function normalizeHistory(history) {
  if (!Array.isArray(history)) return [];

  return history.slice(-8).map((item) => ({
    role: item.role === "user" ? "user" : "assistant",
    content: String(item.text || item.content || "").slice(0, 1000)
  }));
}

app.get("/api/health", (request, response) => {
  response.json({
    ok: true,
    model: hfModel
  });
});

app.post("/api/chat", async (request, response) => {
  const message = String(request.body?.message || "").trim();

  if (!message) {
    response.status(400).json({ error: "Message is required." });
    return;
  }

  if (!hfToken && hfApiBase.includes("huggingface.co")) {
    response.status(500).json({
      error: "Missing HF_TOKEN. Add it to the project .env file."
    });
    return;
  }

  const messages = [
    { role: "system", content: systemPrompt },
    ...normalizeHistory(request.body?.history),
    { role: "user", content: message.slice(0, 1200) }
  ];

  try {
    const headers = {
      "Content-Type": "application/json"
    };

    if (hfToken && hfToken !== "EMPTY") {
      headers.Authorization = `Bearer ${hfToken}`;
    }

    const aiResponse = await fetch(`${hfApiBase.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: hfModel,
        messages,
        temperature: 0.6,
        top_p: 0.95,
        max_tokens: 420,
        stream: false
      })
    });

    const rawBody = await aiResponse.text();

    if (!aiResponse.ok) {
      response.status(aiResponse.status).json({
        error: "Model request failed.",
        detail: rawBody.slice(0, 800)
      });
      return;
    }

    const data = JSON.parse(rawBody);
    const reply = cleanReply(data?.choices?.[0]?.message?.content);

    if (!reply) {
      response.status(502).json({ error: "The model returned an empty reply." });
      return;
    }

    response.json({ reply });
  } catch (error) {
    console.error(error);
    response.status(500).json({
      error: "Could not contact the model."
    });
  }
});

app.listen(port, () => {
  console.log(`Model backend running on http://localhost:${port}`);
});
