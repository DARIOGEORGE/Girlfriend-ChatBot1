import { Heart } from "lucide-react";

export function MessageBubble({ message }) {
  const isUser = message.role === "user";

  return (
    <article className={`message ${isUser ? "userMessage" : "miraMessage"}`}>
      {!isUser && (
        <span className="messageIcon" aria-hidden="true">
          <Heart size={13} fill="currentColor" />
        </span>
      )}
      <p>{message.text}</p>
    </article>
  );
}
