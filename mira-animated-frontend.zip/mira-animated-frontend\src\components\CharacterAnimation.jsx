import { useEffect, useState } from "react";

const imageFilePattern = /\.(gif|png|jpe?g|webp|svg)$/i;
const webmFilePattern = /\.webm$/i;

export function CharacterAnimation({ mood, sources }) {
  const [hasError, setHasError] = useState(false);
  const src = sources[mood] || sources.calm || sources.happy;
  const isImage = imageFilePattern.test(src);
  const videoType = webmFilePattern.test(src) ? "video/webm" : "video/mp4";

  useEffect(() => {
    setHasError(false);
  }, [src]);

  return (
    <div className={`characterStage character-${mood}`} aria-label={`${mood} animation`}>
      <div className="characterGlow" />
      <div className="characterFrame">
        {isImage ? (
          <img
            className="characterMedia"
            src={src}
            alt={`${mood} reaction`}
            onError={() => setHasError(true)}
          />
        ) : (
          <video
            key={src}
            className="characterMedia"
            autoPlay
            loop
            muted
            playsInline
            preload="auto"
            onError={() => setHasError(true)}
          >
            <source src={src} type={videoType} />
          </video>
        )}
        {hasError && (
          <div className="missingAssetHint">
            Place file: <strong>{src.replace("/", "public/")}</strong>
          </div>
        )}
      </div>
    </div>
  );
}
