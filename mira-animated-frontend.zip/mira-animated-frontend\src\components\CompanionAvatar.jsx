export function CompanionAvatar({ mood, isTalking }) {
  return (
    <div className={`avatarWrap ${isTalking ? "talking" : ""}`} aria-hidden="true">
      <div className="halo haloOne" />
      <div className="halo haloTwo" />
      <div className="orb orbA" />
      <div className="orb orbB" />
      <div className="orb orbC" />

      <div className="avatar">
        <div className="hairBack" />
        <div className="neck" />
        <div className="shoulders">
          <div className="collar" />
          <div className="gem" />
        </div>
        <div className="sideHair leftSideHair" />
        <div className="sideHair rightSideHair" />
        <div className="face">
          <div className="fringe fringeLeft" />
          <div className="fringe fringeMid" />
          <div className="fringe fringeRight" />
          <div className="brow leftBrow" />
          <div className="brow rightBrow" />
          <div className="eye leftEye">
            <span />
          </div>
          <div className="eye rightEye">
            <span />
          </div>
          <div className="cheek leftCheek" />
          <div className="cheek rightCheek" />
          <div className="nose" />
          <div className="mouth" />
        </div>
        <div className="ear leftEar" />
        <div className="ear rightEar" />
      </div>

      <div className={`reactionBurst ${mood}`}>
        <span />
        <span />
        <span />
        <span />
        <span />
      </div>
    </div>
  );
}
