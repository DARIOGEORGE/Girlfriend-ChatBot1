import { useEffect, useMemo, useRef, useState } from "react";
import {
  Heart,
  Laugh,
  MessageCircle,
  Send,
  Sparkles,
  WandSparkles
} from "lucide-react";
import { CompanionAvatar } from "./components/CompanionAvatar.jsx";
import { ReactionButton } from "./components/ReactionButton.jsx";
import { MessageBubble } from "./components/MessageBubble.jsx";

const backgroundVideoSrc =
  import.meta.env.VITE_BACKGROUND_VIDEO_SRC || "/videos/chat-background.mp4";

const moodMap = {
  idle: {
    label: "Calm",
    line: "I am here with you.",
    icon: Heart
  },
  happy: {
    label: "Happy",
    line: "That made me smile.",
    icon: Laugh
  },
  shy: {
    label: "Blush",
    line: "You are making me a little shy.",
    icon: Sparkles
  },
  curious: {
    label: "Curious",
    line: "Tell me one more detail.",
    icon: MessageCircle
  },
  magic: {
    label: "Glow",
    line: "I have a good feeling about this.",
    icon: WandSparkles
  }
};

const starterMessages = [
  {
    id: "intro-1",
    role: "mira",
    text: "Hey, I am Mira. I can react while we talk, so try sending me a message."
  },
  {
    id: "intro-2",
    role: "mira",
    text: "For now this is the animated frontend. The model connection can come next."
  }
];

function localReply(message) {
  const lower = message.toLowerCase();

  if (lower.includes("sad") || lower.includes("tired") || lower.includes("bad")) {
    return "Come closer to the calm side of the room for a second. I am listening.";
  }

  if (lower.includes("love") || lower.includes("miss")) {
    return "That is sweet. I will keep this moment soft and warm.";
  }

  if (lower.includes("?")) {
    return "That is a good question. I want to understand what you are really looking for.";
  }

  return "I like the way you said that. Tell me more, slowly.";
}

function pickMood(message) {
  const lower = message.toLowerCase();

  if (lower.includes("love") || lower.includes("cute") || lower.includes("beautiful")) {
    return "shy";
  }

  if (lower.includes("?") || lower.includes("why") || lower.includes("how")) {
    return "curious";
  }

  if (lower.includes("happy") || lower.includes("good") || lower.includes("nice")) {
    return "happy";
  }

  return "magic";
}

export default function App() {
  const [mood, setMood] = useState("idle");
  const [isTalking, setIsTalking] = useState(false);
  const [messages, setMessages] = useState(starterMessages);
  const [input, setInput] = useState("");
  const chatEndRef = useRef(null);
  const moodTimerRef = useRef(null);

  const activeMood = moodMap[mood];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const reactions = useMemo(
    () =>
      Object.entries(moodMap).map(([key, item]) => ({
        key,
        ...item
      })),
    []
  );

  function showMood(nextMood) {
    setMood(nextMood);
    setIsTalking(nextMood !== "idle");

    window.clearTimeout(moodTimerRef.current);
    moodTimerRef.current = window.setTimeout(() => {
      setIsTalking(false);
      setMood("idle");
    }, 2600);
  }

  function handleSubmit(event) {
    event.preventDefault();

    const text = input.trim();
    if (!text) return;

    const nextMood = pickMood(text);
    const userMessage = {
      id: crypto.randomUUID(),
      role: "user",
      text
    };

    setInput("");
    setMessages((current) => [...current, userMessage]);
    showMood(nextMood);

    window.setTimeout(() => {
      setMessages((current) => [
        ...current,
        {
          id: crypto.randomUUID(),
          role: "mira",
          text: localReply(text)
        }
      ]);
    }, 800);
  }

  return (
    <main className={`app mood-${mood}`}>
      <video
        className="backgroundVideo"
        autoPlay
        loop
        muted
        playsInline
        preload="auto"
        aria-hidden="true"
      >
        <source src={backgroundVideoSrc} type="video/mp4" />
      </video>
      <div className="backgroundWash" aria-hidden="true" />

      <section className="stage" aria-label="Animated companion">
        <div className="brand">
          <span className="brandIcon">
            <Sparkles size={18} />
          </span>
          <div>
            <h1>Mira</h1>
            <p>Animated AI companion frontend</p>
          </div>
        </div>

        <CompanionAvatar mood={mood} isTalking={isTalking} />

        <div className="moodStrip" aria-live="polite">
          <span>{activeMood.label}</span>
          <p>{activeMood.line}</p>
        </div>
      </section>

      <section className="conversation" aria-label="Conversation">
        <header className="conversationHeader">
          <div>
            <p className="eyebrow">Local animated demo</p>
            <h2>Make her react while you chat</h2>
          </div>
          <span className="status">Ready</span>
        </header>

        <div className="reactionDock" aria-label="Reaction buttons">
          {reactions.map((reaction) => (
            <ReactionButton
              key={reaction.key}
              label={reaction.label}
              Icon={reaction.icon}
              isActive={mood === reaction.key}
              onClick={() => showMood(reaction.key)}
            />
          ))}
        </div>

        <div className="messages">
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))}
          <div ref={chatEndRef} />
        </div>

        <form className="composer" onSubmit={handleSubmit}>
          <input
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder="Say something to Mira"
            aria-label="Message Mira"
          />
          <button type="submit" aria-label="Send message">
            <Send size={20} />
          </button>
        </form>
      </section>
    </main>
  );
}
