import { useEffect, useMemo, useRef, useState } from "react";
import {
  HeartHandshake,
  Laugh,
  Send,
  Sparkles
} from "lucide-react";
import { CharacterAnimation } from "./components/CharacterAnimation.jsx";
import { ReactionButton } from "./components/ReactionButton.jsx";
import { MessageBubble } from "./components/MessageBubble.jsx";

const backgroundVideoSrc =
  import.meta.env.VITE_BACKGROUND_VIDEO_SRC || "/videos/chat-background.mp4";

const appName = import.meta.env.VITE_APP_NAME || "Companion";

const animationSources = {
  happy: import.meta.env.VITE_HAPPY_ANIMATION_SRC || "/animations/happy.mp4",
  blush: import.meta.env.VITE_BLUSH_ANIMATION_SRC || "/animations/blush.mp4",
  calm: import.meta.env.VITE_CALM_ANIMATION_SRC || "/animations/calm.mp4"
};

const moodMap = {
  happy: {
    label: "Happy",
    line: "That made me smile.",
    icon: Laugh
  },
  blush: {
    label: "Blush",
    line: "That made me blush.",
    icon: Sparkles
  },
  calm: {
    label: "Calm",
    line: "I am here with you.",
    icon: HeartHandshake
  }
};

const starterMessages = [
  {
    id: "intro-1",
    role: "companion",
    text: "Hey, I can react while we talk. Try the Happy, Blush, and Calm buttons."
  },
  {
    id: "intro-2",
    role: "companion",
    text: "Drop your three animation files into the animations folder, and I will switch between them."
  }
];

function localReply(message) {
  const lower = message.toLowerCase();

  if (lower.includes("sad") || lower.includes("tired") || lower.includes("bad")) {
    return "Come closer to the calm side of the room for a second. I am listening.";
  }

  if (lower.includes("love") || lower.includes("miss")) {
    return "That is sweet. I am keeping this moment soft and warm.";
  }

  if (lower.includes("?")) {
    return "That is a good question. I want to understand what you are really looking for.";
  }

  return "I like the way you said that. Tell me more, slowly.";
}

function pickMood(message) {
  const lower = message.toLowerCase();

  if (lower.includes("calm") || lower.includes("sad") || lower.includes("tired") || lower.includes("bad")) {
    return "calm";
  }

  if (
    lower.includes("love") ||
    lower.includes("miss") ||
    lower.includes("cute") ||
    lower.includes("beautiful") ||
    lower.includes("shy") ||
    lower.includes("blush")
  ) {
    return "blush";
  }

  return "happy";
}

export default function App() {
  const [mood, setMood] = useState("calm");
  const [messages, setMessages] = useState(starterMessages);
  const [input, setInput] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const chatEndRef = useRef(null);
  const moodTimerRef = useRef(null);

  const activeMood = moodMap[mood];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const reactions = useMemo(
    () =>
      Object.entries(moodMap).map(([key, item]) => ({
        key,
        ...item
      })),
    []
  );

  function showMood(nextMood) {
    setMood(nextMood);

    window.clearTimeout(moodTimerRef.current);
    moodTimerRef.current = window.setTimeout(() => {
      setMood("calm");
    }, 3600);
  }

  async function getModelReply(message, history) {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        message,
        history
      })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data?.detail || data?.error || "Model request failed.");
    }

    return data.reply;
  }

  async function handleSubmit(event) {
    event.preventDefault();

    const text = input.trim();
    if (!text || isThinking) return;

    const nextMood = pickMood(text);
    const userMessage = {
      id: crypto.randomUUID(),
      role: "user",
      text
    };
    const modelHistory = [...messages, userMessage].slice(-8);

    setInput("");
    setMessages((current) => [...current, userMessage]);
    showMood(nextMood);
    setIsThinking(true);

    try {
      const reply = await getModelReply(text, modelHistory);
      setMessages((current) => [
        ...current,
        {
          id: crypto.randomUUID(),
          role: "companion",
          text: reply
        }
      ]);
      showMood(pickMood(reply));
    } catch (error) {
      console.error(error);
      setMessages((current) => [
        ...current,
        {
          id: crypto.randomUUID(),
          role: "companion",
          text: `I could not reach the model yet. ${localReply(text)}`
        }
      ]);
    } finally {
      setIsThinking(false);
    }
  }

  return (
    <main className={`app mood-${mood}`}>
      <video
        className="backgroundVideo"
        autoPlay
        loop
        muted
        playsInline
        preload="auto"
        aria-hidden="true"
      >
        <source src={backgroundVideoSrc} type="video/mp4" />
      </video>
      <div className="backgroundWash" aria-hidden="true" />

      <section className="stage" aria-label="Animated companion">
        <div className="brand">
          <span className="brandIcon">
            <Sparkles size={18} />
          </span>
          <div>
            <h1>{appName}</h1>
            <p>Three-reaction animated frontend</p>
          </div>
        </div>

        <CharacterAnimation mood={mood} sources={animationSources} />

        <div className="moodStrip" aria-live="polite">
          <span>{activeMood.label}</span>
          <p>{activeMood.line}</p>
        </div>
      </section>

      <section className="conversation" aria-label="Conversation">
        <header className="conversationHeader">
          <div>
            <p className="eyebrow">Local animated demo</p>
            <h2>Make her react while you chat</h2>
          </div>
          <span className="status">{isThinking ? "Thinking" : "Ready"}</span>
        </header>

        <div className="reactionDock" aria-label="Reaction buttons">
          {reactions.map((reaction) => (
            <ReactionButton
              key={reaction.key}
              label={reaction.label}
              Icon={reaction.icon}
              isActive={mood === reaction.key}
              onClick={() => showMood(reaction.key)}
            />
          ))}
        </div>

        <div className="messages">
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))}
          {isThinking && (
            <article className="message companionMessage">
              <span className="messageIcon" aria-hidden="true">
                <Sparkles size={13} />
              </span>
              <p className="typingDots">
                <span />
                <span />
                <span />
              </p>
            </article>
          )}
          <div ref={chatEndRef} />
        </div>

        <form className="composer" onSubmit={handleSubmit}>
          <input
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder="Say something"
            aria-label="Message"
          />
          <button type="submit" aria-label="Send message" disabled={isThinking}>
            <Send size={20} />
          </button>
        </form>
      </section>
    </main>
  );
}
