# Animation Plugins

## Recommended For Version 1

### 1. Rive

Package:

```bash
npm install @rive-app/react-webgl2
```

Use for:

- main girlfriend/avatar animation
- idle, happy, thinking, talking states
- click/touch reactions

Why:

- polished character animation
- good for web
- supports state machines
- easier than VRM for beginners

Official docs: https://rive.app/docs/runtimes/react/react

### 2. Lottie

Package:

```bash
npm install lottie-react
```

Use for:

- hearts
- sparkles
- message reactions
- loading animation
- small mood effects

Why:

- lightweight JSON animations
- many free assets available
- simple React component

Official docs: https://lottiereact.com/

### 3. Motion

Package:

```bash
npm install motion
```

Use for:

- chat bubble entrance animation
- smooth page transitions
- hover/tap animations
- panel movement

Why:

- clean React animation library
- modern replacement path for Framer Motion usage
- very good for UI animations

Official docs: https://motion.dev/docs/react

## Optional Later

### 4. Three.js + React Three Fiber

Packages:

```bash
npm install three @react-three/fiber @react-three/drei
```

Use for:

- 3D scenes
- lighting
- camera controls
- 3D backgrounds

Official docs: https://r3f.docs.pmnd.rs/getting-started/installation

### 5. VRM Avatar

Package:

```bash
npm install @pixiv/three-vrm
```

Use for:

- full 3D anime avatar
- body/head movement
- custom 3D model

Use later. It is stronger but harder than Rive.

Official repo: https://github.com/pixiv/three-vrm

### 6. GSAP

Package:

```bash
npm install gsap
```

Use for:

- complex timelines
- cinematic page animation
- advanced sequencing

Use only when Motion is not enough.

Official site: https://gsap.com/

## My Recommendation

Do not build version 1 with every animation system active.

Use:

```text
Rive + Lottie + Motion
```

Keep:

```text
Three.js + VRM + GSAP
```

for later upgrades.
