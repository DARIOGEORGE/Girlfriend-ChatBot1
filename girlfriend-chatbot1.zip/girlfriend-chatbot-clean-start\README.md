# Girlfriend Chatbot Clean Start

This folder is a fresh base for your animated AI companion project.

It does not include full app code yet. It only includes the free/open-source animation packages and the necessary project setup files.

## First Choice

Start with this combo:

1. **Rive** for the main animated character.
2. **Lottie** for hearts, sparkles, reactions, loading, and small effects.
3. **Motion** for chat bubbles, panels, buttons, and smooth UI transitions.

Use VRM/Three.js later only if you want a full 3D avatar.

## Install In Windows VM

Open this folder in VS Code, then run:

```powershell
npm install
npm run dev
```

## Asset Folders

Put files here:

```text
public/animations/avatar.riv
public/animations/idle.json
public/models/avatar.vrm
src/assets
```

## No Billing Version

For now, do not use Firebase Cloud Functions. They require billing.

You can first build:

- character animation
- chat screen UI
- local demo replies
- local browser storage

Then later add backend and real AI.

## Best Free Animation Plugins

See `ANIMATION_PLUGINS.md`.
