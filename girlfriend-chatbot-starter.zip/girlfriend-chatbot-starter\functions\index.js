const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { logger } = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();

const hfToken = defineSecret("HF_TOKEN");

const SYSTEM_PROMPT = `
You are Mira, an affectionate AI companion inside a chat app.
Be warm, playful, emotionally supportive, and concise.
Be honest that you are an AI companion if asked.
Do not claim to be a real human.
Do not encourage unhealthy dependency, isolation, self-harm, or unsafe behavior.
If the user seems distressed, respond with care and encourage real-world support.
`;

exports.chat = onCall(
  {
    region: "us-central1",
    timeoutSeconds: 60,
    secrets: [hfToken]
  },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Please sign in first.");
    }

    const message = String(request.data?.message || "").trim();
    if (!message) {
      throw new HttpsError("invalid-argument", "Message is required.");
    }

    if (message.length > 1200) {
      throw new HttpsError("invalid-argument", "Message is too long.");
    }

    const history = Array.isArray(request.data?.history)
      ? request.data.history.slice(-10)
      : [];

    const messages = [
      { role: "system", content: SYSTEM_PROMPT },
      ...history
        .filter((item) => item?.role && item?.content)
        .map((item) => ({
          role: item.role === "assistant" ? "assistant" : "user",
          content: String(item.content).slice(0, 1200)
        })),
      { role: "user", content: message }
    ];

    try {
      const response = await fetch("https://router.huggingface.co/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${hfToken.value()}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "Qwen/Qwen3-4B-Instruct-2507:fastest",
          messages,
          temperature: 0.8,
          max_tokens: 260,
          stream: false
        })
      });

      if (!response.ok) {
        const body = await response.text();
        logger.error("Hugging Face request failed", {
          status: response.status,
          body: body.slice(0, 500)
        });
        throw new HttpsError("internal", "AI service failed.");
      }

      const data = await response.json();
      const reply = data?.choices?.[0]?.message?.content?.trim();

      if (!reply) {
        throw new HttpsError("internal", "AI service returned no reply.");
      }

      return { reply };
    } catch (error) {
      if (error instanceof HttpsError) {
        throw error;
      }

      logger.error("Unexpected chat error", error);
      throw new HttpsError("internal", "Could not create reply.");
    }
  }
);
