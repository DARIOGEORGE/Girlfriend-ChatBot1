import Rive from "@rive-app/react-webgl2";

const riveSrc = import.meta.env.VITE_RIVE_AVATAR_SRC;

export function AvatarStage({ mood, isThinking }) {
  if (riveSrc) {
    return (
      <div className="avatarStage">
        <Rive
          src={riveSrc}
          stateMachines="Companion"
          autoplay
          className="riveAvatar"
        />
      </div>
    );
  }

  return (
    <div className={`avatarStage cssAvatar ${mood} ${isThinking ? "thinking" : ""}`}>
      <div className="aura" />
      <div className="hair hairBack" />
      <div className="neck" />
      <div className="face">
        <div className="bang bangOne" />
        <div className="bang bangTwo" />
        <div className="eye leftEye" />
        <div className="eye rightEye" />
        <div className="blush leftBlush" />
        <div className="blush rightBlush" />
        <div className="mouth" />
      </div>
      <div className="hair hairLeft" />
      <div className="hair hairRight" />
      <div className="shoulders" />
      <div className="pulseDot dotOne" />
      <div className="pulseDot dotTwo" />
      <div className="pulseDot dotThree" />
    </div>
  );
}
