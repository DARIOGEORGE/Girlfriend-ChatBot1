import { Heart } from "lucide-react";

export function ChatWindow({ messages, isThinking }) {
  return (
    <div className="messageList" aria-live="polite">
      {messages.map((message) => (
        <article
          className={`messageBubble ${message.role === "user" ? "fromUser" : "fromBot"}`}
          key={message.id}
        >
          {message.role === "assistant" && (
            <span className="miniIcon" aria-hidden="true">
              <Heart size={14} fill="currentColor" />
            </span>
          )}
          <p>{message.text}</p>
        </article>
      ))}

      {isThinking && (
        <article className="messageBubble fromBot">
          <span className="miniIcon" aria-hidden="true">
            <Heart size={14} fill="currentColor" />
          </span>
          <p className="typing">
            <span />
            <span />
            <span />
          </p>
        </article>
      )}
    </div>
  );
}
