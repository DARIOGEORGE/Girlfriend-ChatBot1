import { useEffect, useMemo, useRef, useState } from "react";
import { Bot, Send, ShieldCheck } from "lucide-react";
import { signInAnonymously, onAuthStateChanged } from "firebase/auth";
import {
  addDoc,
  collection,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp
} from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { auth, db, functions, isFirebaseConfigured } from "./firebase.js";
import { AvatarStage } from "./components/AvatarStage.jsx";
import { ChatWindow } from "./components/ChatWindow.jsx";

const demoMessages = [
  {
    id: "hello",
    role: "assistant",
    text: "Hey, I am here. Tell me what kind of day you are having.",
    createdAt: Date.now()
  }
];

function makeLocalReply(message) {
  const clean = message.trim();
  if (!clean) return "I am listening.";
  return `I hear you. "${clean}" sounds important. Want to tell me a little more?`;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [messages, setMessages] = useState(demoMessages);
  const [text, setText] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [mood, setMood] = useState("soft");
  const inputRef = useRef(null);

  const canUseCloud = isFirebaseConfigured && user;

  useEffect(() => {
    if (!isFirebaseConfigured) return undefined;

    const unsubscribe = onAuthStateChanged(auth, async (nextUser) => {
      if (nextUser) {
        setUser(nextUser);
        return;
      }

      await signInAnonymously(auth);
    });

    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!canUseCloud) return undefined;

    const messagesRef = collection(
      db,
      "users",
      user.uid,
      "chats",
      "default",
      "messages"
    );
    const messagesQuery = query(messagesRef, orderBy("createdAt", "asc"), limit(80));

    return onSnapshot(messagesQuery, (snapshot) => {
      const nextMessages = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data()
      }));

      if (nextMessages.length > 0) {
        setMessages(nextMessages);
      }
    });
  }, [canUseCloud, user]);

  const recentHistory = useMemo(
    () =>
      messages.slice(-10).map((message) => ({
        role: message.role,
        content: message.text
      })),
    [messages]
  );

  async function saveMessage(role, nextText) {
    const nextMessage = {
      role,
      text: nextText,
      createdAt: canUseCloud ? serverTimestamp() : Date.now()
    };

    if (!canUseCloud) {
      setMessages((current) => [
        ...current,
        { ...nextMessage, id: crypto.randomUUID() }
      ]);
      return;
    }

    await addDoc(
      collection(db, "users", user.uid, "chats", "default", "messages"),
      nextMessage
    );
  }

  async function handleSend(event) {
    event.preventDefault();

    const message = text.trim();
    if (!message || isThinking) return;

    setText("");
    setMood("bright");
    await saveMessage("user", message);
    setIsThinking(true);

    try {
      if (!canUseCloud) {
        await new Promise((resolve) => setTimeout(resolve, 700));
        await saveMessage("assistant", makeLocalReply(message));
        return;
      }

      const chat = httpsCallable(functions, "chat");
      const result = await chat({ message, history: recentHistory });
      await saveMessage("assistant", result.data.reply);
    } catch (error) {
      console.error(error);
      await saveMessage(
        "assistant",
        "Something went wrong on my side. Please try again in a moment."
      );
    } finally {
      setIsThinking(false);
      setMood("soft");
      inputRef.current?.focus();
    }
  }

  return (
    <main className="appShell">
      <section className="companionPane" aria-label="Companion avatar">
        <div className="brandRow">
          <div className="brandMark">
            <Bot size={20} strokeWidth={2.4} />
          </div>
          <div>
            <h1>Mira</h1>
            <p>{canUseCloud ? "Online" : "Local demo"}</p>
          </div>
        </div>

        <AvatarStage mood={mood} isThinking={isThinking} />

        <div className="safetyNote">
          <ShieldCheck size={18} />
          <span>AI companion, private chat space</span>
        </div>
      </section>

      <section className="chatPane" aria-label="Chat">
        <ChatWindow messages={messages} isThinking={isThinking} />

        <form className="composer" onSubmit={handleSend}>
          <input
            ref={inputRef}
            value={text}
            onChange={(event) => setText(event.target.value)}
            placeholder="Message Mira"
            aria-label="Message Mira"
          />
          <button type="submit" disabled={!text.trim() || isThinking} aria-label="Send">
            <Send size={20} />
          </button>
        </form>
      </section>
    </main>
  );
}
