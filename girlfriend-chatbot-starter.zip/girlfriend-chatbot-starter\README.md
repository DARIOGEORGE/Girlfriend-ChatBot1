# AI Companion Chatbot Starter

This is a beginner-friendly React + Firebase + Hugging Face starter for an animated AI companion chatbot.

## Best Animation Choice

Use **Rive first**.

- Rive is better than VRM for a beginner web chatbot because it gives polished 2D/2.5D character animation, state machines, and small web-friendly files.
- VRM is better later if you want full 3D avatar movement, camera angles, outfits, and game-like interaction.
- Live2D looks excellent for anime-style companions, but model creation and licensing are harder than Rive.

This starter uses a CSS avatar immediately and supports Rive when you add a `.riv` file.

## Open In VS Code

Open this folder:

```bash
code .
```

## Install

```bash
npm install
cd functions
npm install
cd ..
```

## Firebase Setup

1. Create a Firebase project.
2. Add a Web app in Firebase project settings.
3. Enable Authentication.
4. Turn on Anonymous sign-in.
5. Enable Firestore.
6. Enable Cloud Functions.
7. Enable Hosting.

Copy `.env.example` to `.env` and fill the Firebase values.

## Hugging Face Setup

Create a Hugging Face token, then set it as a Firebase Functions secret:

```bash
firebase functions:secrets:set HF_TOKEN
```

When it asks for a value, paste your Hugging Face token.

The backend currently uses:

```text
Qwen/Qwen3-4B-Instruct-2507:fastest
```

You can change this in `functions/index.js`.

## Run Locally

```bash
npm run dev
```

If your Firebase config is missing, the app runs in local demo mode.

## Deploy

```bash
firebase login
firebase use --add
npm run build
firebase deploy
```

This starter already includes `firebase.json` and `firestore.rules`, so `firebase use --add` is enough to connect your local folder to your Firebase project.

## Add A Rive Avatar

1. Create or download a `.riv` file from Rive.
2. Put it in `public/avatar.riv`.
3. Add this to `.env`:

```bash
VITE_RIVE_AVATAR_SRC=/avatar.riv
```

If your Rive file has a state machine named `Companion`, the component is already ready for it.

## Important Safety Notes

- Never put your Hugging Face token in frontend React code.
- Keep it only in Firebase Functions secrets.
- Tell users the companion is AI.
- Add age gates and stricter rules before any adult/romantic production app.
